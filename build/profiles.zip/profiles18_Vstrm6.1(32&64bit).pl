# -----------------
# global declares
# -----------------

use vars qw(
	$VSSROOT $VSSUSER $VSSPASSWD $VSSSERVER $SOSDATABASE
	$BUILD_SETTINGS $BUILD_ROOT $RELEASE_ROOT %BUILD_BATCH $SSCMD $MSDEV6CMD $MSDEV7CMD
	$EMAILATTNS
	);

($VSSROOT, $VSSSERVER, $VSSUSER, $VSSPASSWD, $SOSDATABASE, $BUILD_SETTINGS, $BUILD_ROOT, $RELEASE_ROOT)
=  ("\\\\192.168.80.7\\vss\\vssmore\\DSE1\\VSS-DSE1Main","192.168.87.4:8080", "build", "nightly", "D:\\VSS\\vssmore\\DSE1\\VSS-Releases\\DSE1_TianShan.1.8\\srcsafe.ini", "ZQProjs/build", "d:\\build", "\\\\10.50.12.2\\e\$\\build");
# =  ("\\\\ProjectServer\\vssmore\\DSE1\\VSS-DSE1Main", "build", "nightly", "ZQProjs/build", "c:\\temp", "\\\\hawkeye\\builds");

$MSVS6_INST = "C:\\Program Files (x86)\\Microsoft Visual Studio";
$MSVS7_INST = "C:\\Program Files (x86)\\Microsoft Visual Studio .NET 2003";
$MSVS8_INST = "C:\\Program Files (x86)\\Microsoft Visual Studio 8";
$SSCMD = "\"C:\\Program Files (x86)\\SourceOffSite\\soscmd.exe\"";
$MSDEV6CMD = "\"$MSVS6_INST\\Common\\MSDev98\\Bin\\MSDEV.EXE\"";
$MSDEV7CMD = "\"$MSVS7_INST\\Common7\\IDE\\DEVENV.EXE\"";
$MSDEV8CMD = "\"$MSVS8_INST\\Common7\\IDE\\DEVENV.EXE\"";

$EMAILATTNS='hui.shao@i-zq.com,jie.zhang@i-zq.com,bernie.zhao@i-zq.com,ken.qian@i-zq.com,daniel.wang@i-zq.com,lin.ouyang@i-zq.com,mei.zhang@i-zq.com';

use vars qw (
	@NIGHLY_PROJLIST,
	@WORK_PROJLIST,
);
	
# -----------------
# projects build profiles
# -----------------

my %ProjTemplate = (
	'name'			=> 'ProjectTemplate',	# short name of the project, no white spaces allowed here
	'environment'           => {
        	                     'variable'  => 'path',
        	                },   # set private environment variable for this project
	'prod_ver'		=> '0.1.0',		# <major_ver>.<minor_ver>.<patch_number>
	'sources'		=> ['ZQProjs/Common',
						'ZQProjs/ProjTemplate'], # necessary source sub-tree to build this project
	'work_path'		=> 'ZQProjs\\ProjTemplate',		 # the working path when build this project
	'rc_h_files'	=> ['ZQProjs\\ProjTemplate\\console\\ZQResource.h'], # the ZQResource.h files that must be updated with the version info
	'build_cmds'	=> ["$MSDEV6CMD ProjTemplate.dsw /MAKE \"console - Win32 Release\" /REBUILD" ], # the command lines to run the build processes
	'output_pkg'	=> ["ZQProjs\\ProjTemplate\\console\\Release\\console.exe" ], # the final packages from the build process(es)
);


%TianShanDataOnDemand = (
	'name'		=> 'TianShanDataOnDemand',
	'desc'		=> 'DataOnDemand Application Service',
	'environment'           => {
				     'WPCAPSDKPATH'	 => 'D:\\SDK\\3rdPartyKits\\WpdPack_4_0_2',
        	                     'ICE_ROOT'		=> 'D:\\Ice-3.2.1-VC80-x86',
        	                     'STLPORT_ROOT'	=> 'D:\\Ice-3.2.1-VC80-x86\\include\\stlport',
        	                     'ExpatPath'         => 'D:\\SDK\\3rdPartyKits\\expat',
        	                     'RegExppKit'        => 'D:\\SDK\\3rdPartyKits\\regexpp1331',
        	                }, 
	'owner'		=> ['Ken.Qian@i-zq.com','cary.xiao@i-zq.com','li.huang@i-zq.com'],
	'prod_ver'	=> '3.1.1',
	'sources'	=> ['ZQProjs/DataOnDemand','ZQProjs/Common','ZQProjs/TianShan','ZQProjs/generic/JMSCppLib','ZQProjs/generic/ContentProcess','ZQProjs/generic/TsDump'],
	'work_path'	=> "ZQProjs\\DataOnDemand",
	'rc_h_files'	=> ["ZQProjs\\DataOnDemand\\Phase2\\DODApp\\ZQResource.h",
	                    "ZQProjs\\DataOnDemand\\Phase2\\DataStream\\ZQResource.h",
	                    "ZQProjs\\DataOnDemand\\Phase2\\DODApp\\JMSDispatch\\ZQResource.h",
	                    "ZQProjs\\DataOnDemand\\Phase2\\DODContentStore\\ZQResource.h",
	                    "ZQProjs\\DataOnDemand\\Phase2\\DodPho\\ZQResource.h",
	                    "ZQProjs\\TianShan\\Shell\\ZQShell\\ZQResource.h",
	                    "ZQProjs\\Generic\\TsDump\\ZQResource.h",
	                    ],
	'build_cmds'=> [
			"$MSDEV8CMD /Rebuild  \"Release|win32\" /project Buildall /out DOD_build.log DataOnDemand.sln",
	                "DataOnDemand.bat"],
	'output_pkg'	=> ["ZQProjs\\DataOnDemand\\DataOnDemand_Setup.zip" ],
);

%TianShan = (
	'name'		=> 'TianShan',
	'desc'		=> 'TianShan Components',
	'xml_path'	=> ['ZQProjs\\TianShan\\etc','ZQProjs\\TianShan\\VirtualStreamingSerivce\\NGOD'],
        'environment'           => {
        	                     #'VSTRMKITPATH'        => 'D:\\sdk\\SeaChangeKits\\VstrmKitV5.4.5',           #For NGOD
        	                     #'VSTRMKITPATH'        => 'D:\\SDK\\SeaChangeKits\\VstrmKitV6.0.2.6',
        	                     'VSTRMKITPATH'        => 'D:\\SDK\\SeaChangeKits\\VstrmKitV6.0-next-20090514',
        	                     'WPCAPSDKPATH'	 => 'D:\\SDK\\3rdPartyKits\\WpdPack_4_0_2',
        	                     #'RTFLIBSDKPATH'      => 'D:\\SDK\\SeaChangeKits\\RTFLib_SDK_1.6',
        	                     #'RTFLIBSDKPATH'      => 'D:\\SDK\\SeaChangeKits\\RTFLib_SDK_2.0',
        	                     'RTFLIBSDKPATH'      => 'D:\\sdk\\SeaChangeKits\\CTFLib_1.0.0.18',
        	                     'OPENSSLPATH'      => 'D:\\SDK\\3rdPartyKits\\openssl',
        	                     'ICE_ROOT'		=> 'D:\\SDK\\3rdPartyKits\\Ice-3.2.1-VC80-x86',
        	                     'STLPORT_ROOT'	=> 'D:\\SDK\\3rdPartyKits\\Ice-3.2.1-VC80-x86\\include\\stlport',
        	                     '3RDPARTYKITS_PATH' => 'D:\\SDK\\3rdPartyKits',
        	                     'ExpatPath'         => 'D:\\SDK\\3rdPartyKits\\expat',
        	                     'RegExppKit'        => 'D:\\SDK\\3rdPartyKits\\regexpp1331',
        	                     'ANT_HOME'          => 'D:\\SDK\\3rdPartyKits\\apache-ant-1.6.5',
        	                     'SNMP_PLUS_ROOT'    => 'D:\\SDK\\3rdPartyKits\\SNMP',
        	                     'GSOAPPATH'	=>  'D:\\SDK\\3rdPartyKits\\gsoap-2.7.10\\gsoap',
        	                }, 
	'owner'		=> ['hui.shao@i-zq.com','ken.qian@i-zq.com','jie.zhang@i-zq.com'],
	'prod_ver'	=> '1.8.1',
	'sources'	=> ['ZQProjs/Common','ZQProjs/TianShan','ZQProjs/generic',],
	'work_path'	=> "ZQProjs\\TianShan",
	'rc_h_files'	=> [
			    "ZQProjs/Common/ZQCommVer.h",
	                    "ZQProjs/TianShan/ChannelOnDemand/PauseTVVersion.h",
	                    "ZQProjs/TianShan/StreamSmith/Service/ZQResource.h",
	                    "ZQProjs/TianShan/StreamSmith/Service/RtspProxyResource.h",
	                    "ZQProjs/TianShan/ContentStore/MediaCluster/ClusterContentStore/ZQResource.h",
	                    "ZQProjs/TianShan/ContentStore/MediaCluster/NodeContentStore/ZQResource.h",
	                    "ZQProjs/TianShan/ContentStore/MediaCluster/NASContentStore/ZQResource.h",
	                    "ZQProjs/TianShan/ContentStore/ContentClient/ZQResource.h",
	                    "ZQProjs/TianShan/ContentStore/RDS/ZQResource.h",
	                    "ZQProjs/TianShan/ContentStore/RDA/ZQResource.h",
	                    "ZQProjs/TianShan/ContentStore/isaLink/isaLink/ZQResource.h",
	                    "ZQProjs/TianShan/StreamSmith/Modules/SsmTianShanS1_Now/ZQResource.h",
	                    "ZQProjs/TianShan/StreamSmith/Modules/ssm_tianshan/ZQResource.h",
	                    "ZQProjs/TianShan/StreamSmith/Modules/ssm_richurl/ZQResource.h",
	                    "ZQProjs/TianShan/Weiwoo/Service/ZQResource.h",
	                    "ZQProjs/TianShan/AccreditedPath/AdminControl/ZQResource.h",
	                    "ZQProjs/TianShan/AccreditedPath/ZQResource.h",
	                    "ZQProjs/TianShan/AccreditedPath/TestAdminCtl/ZQResource.h",
	                    "ZQProjs/TianShan/AccreditedPath/pho/pho_SeaChange/ZQResource.h",
	                    "ZQProjs/TianShan/application/MOD/ZQResource.h",
	                    "ZQProjs/TianShan/application/MOD2/ZQResource.h",
	                    "ZQProjs/TianShan/application/MODPlugIn/ZQResource.h",
	                    "ZQProjs/TianShan/Shell/ZQShell/ZQResource.h",
	                    "ZQProjs/TianShan/Sentry/Service/ZQResource.h",
	                    "ZQProjs/TianShan/SiteAdminSvc/Service/ZQResource.h",
	                    "ZQProjs/TianShan/ComcastNGOD/ssmNGODr2c1(Improved)/ZQResource.h",
	                    "ZQProjs/TianShan/ComcastNGOD/pho_NGOD_ss/ZQResource.h",
	                    "ZQProjs/TianShan/ComcastNGOD/ssm_ngod2/ZQResource.h",
	                    "ZQProjs/TianShan/ComcastNGOD/NSS/ZQResource.h",
	                    "ZQProjs/TianShan/ComcastNGOD/NSS/TSHammer/ZQResource.h",
	                    "ZQProjs/TianShan/ComcastNGOD/pho_NGOD/pho_NGOD/ZQResource.h",
	                    "ZQProjs/TianShan/Sentry/Plug_EventSender/snmp/ZQResource.h",
	                    "ZQProjs/TianShan/Sentry/Plug_EventSender/ZQResource.h",
	                    "ZQProjs/TianShan/Sentry/CodMan_web/ZQResource.h",
	                    "ZQProjs/TianShan/Sentry/AdminCtrl_web/ZQResource.h",
	                    "ZQProjs/TianShan/Sentry/CPCMan_web/ZQResource.h",
	                    "ZQProjs/TianShan/Sentry/CPEMan_web/ZQResource.h",
	                    "ZQProjs/TianShan/Sentry/Module/SysLogSender/ZQResource.h",
	                    "ZQProjs/TianShan/AccreditedPath/admin/ZQResource.h",
	                    "ZQProjs/TianShan/SiteAdminSvc/admin/ZQResource.h",
	                    "ZQProjs/TianShan/EventChannel/service/ZQResource.h",
	                    "ZQProjs/TianShan/CPE/ZQResource.h",
	                    "ZQProjs/TianShan/CPE/CPH_RDS/ZQResource.h",
	                    "ZQProjs/TianShan/CPE/CPH_RTFRDS/ZQResource.h",
	                    "ZQProjs/TianShan/CPE/CPH_NASCOPY/ZQResource.h",
	                    "ZQProjs/TianShan/CPE/CPH_RTI/ZQResource.h",
	                    "ZQProjs/TianShan/CPE/CPH_RTINAS/ZQResource.h",
	                    "ZQProjs/TianShan/EventGateway/service/ZQResource.h",
	                    "ZQProjs/TianShan/EventGateway/Modules/EGH_SOAP/EGH_SOAP_CME/ZQResource.h",
	                    "ZQProjs/TianShan/ComcastNGOD/ssm_ngod2/ngod2view/ZQResource.h",
	                    "ZQProjs/TianShan/VirtualStreamingSerivce/NGOD/ZQResource.h",
	                    "ZQProjs/TianShan/VirtualStreamingSerivce/pho/ZQResource.h",
	                    "ZQProjs/TianShan/VirtualStreamingSerivce/SsmHsnTree/ZQResource.h",
	                    "ZQProjs/TianShan/VirtualStreamingSerivce/HSN/ZQResource.h",
	                    "ZQProjs/TianShan/ICE/TianShanIce.ICE",
	                    ],
	'build_cmds'=> [
	                "set RTFLIBSDKPATH=D:\\SDK\\SeaChangeKits\\RTFLib_SDK_1.6\n$MSDEV8CMD /Rebuild  \"Release|win32\" /project CPE /out CPE_x86.log TianShanBuild.sln",
			"set RTFLIBSDKPATH=D:\\SDK\\SeaChangeKits\\RTFLib_SDK_1.6\nset VSTRMKITPATH=D:\\SDK\\SeaChangeKits\\VstrmKitV6.0-next-20090514\nset ICE_ROOT=D:\\SDK\\3rdPartyKits\\Ice-3.2.1-VC80-x64\nset ExpatPath=D:\\sdk\\3rdPartyKits\\expat_x64\n$MSDEV8CMD /Rebuild  \"Release|x64\" /project CPE_x64 /out CPE_x64.log TianShanBuild.sln",
			"set RTFLIBSDKPATH=D:\\SDK\\SeaChangeKits\\RTFLib_SDK_1.6\nComponents4RTF.V1.6.bat",
			"set RTFLIBSDKPATH=D:\\SDK\\SeaChangeKits\\RTFLib_SDK_2.0\n$MSDEV8CMD /Rebuild  \"Release|win32\" /project CPE /out CPE_x86.log TianShanBuild.sln",
			"set RTFLIBSDKPATH=D:\\SDK\\SeaChangeKits\\RTFLib_SDK_2.0\nset VSTRMKITPATH=D:\\SDK\\SeaChangeKits\\VstrmKitV6.0-next-20090514\nset ICE_ROOT=D:\\SDK\\3rdPartyKits\\Ice-3.2.1-VC80-x64\nset ExpatPath=D:\\sdk\\3rdPartyKits\\expat_x64\n$MSDEV8CMD /Rebuild  \"Release|x64\" /project CPE_x64 /out CPE_x64.log TianShanBuild.sln",
			"set RTFLIBSDKPATH=D:\\SDK\\SeaChangeKits\\RTFLib_SDK_2.0\nComponents4RTF.V2.0.bat",
			"set VSTRMKITPATH=D:\\SDK\\SeaChangeKits\\VstrmKitV6.0-next-20090514\nset ICE_ROOT=D:\\SDK\\3rdPartyKits\\Ice-3.2.1-VC80-x64\nset ExpatPath=D:\\sdk\\3rdPartyKits\\expat_x64\n$MSDEV8CMD /ReBuild  \"Release|x64\" /project Buildall_x64 /out opt_x64.log TianShanBuild.sln",
	                "set VSTRMKITPATH=D:\\SDK\\SeaChangeKits\\VstrmKitV6.0-next-20090514\nset ICE_ROOT=D:\\SDK\\3rdPartyKits\\Ice-3.2.1-VC80-x64\nset ExpatPath=D:\\sdk\\3rdPartyKits\\expat_x64\nTianShanPKG_64.bat",
	                "$MSDEV8CMD /Rebuild  \"Release|win32\" /project Buildall /out opt_x86.log TianShanBuild.sln",
	                "$MSDEV8CMD /Rebuild  \"Java|win32\" /project TianShanIce TianShanBuild.sln",
	                "$MSDEV8CMD /Rebuild  \"Java|win32\" /project JavaClient TianShanBuild.sln",
	                ".\\ChannelOnDemand\\JavaClient\\PkJavaClient.bat",
                        ".\\SDK\\packsdk.bat",
	                "TianShanPKG.bat",
	                ],
	'output_pkg'	=> ["ZQProjs\\TianShan\\TianShan_setup.zip","ZQProjs\\TianShan\\TianShanSymbols.zip" ],
);


%TianShan_x64 = (
	'name'		=> 'TianShan_x64',
	'desc'		=> 'TianShan Components',
	'skippublish'	=> '1',
        'environment'           => {
		                     'ITVSDKPATH'       => 'D:\\sdk\\SeaChangeKits\\ITVSDK-v3.2.INTERNAL',
		                     'VSTRMKITPATH'        => 'D:\\SDK\\SeaChangeKits\\VstrmKitV6.0.2.6',
        	                     'WPCAPSDKPATH'	 => 'D:\\SDK\\3rdPartyKits\\WpdPack_4_0_2',
        	                     #'RTFLIBSDKPATH'      => 'D:\\SDK\\SeaChangeKits\\RTFLib_SDK_1.6',
        	                     #'RTFLIBSDKPATH'      => 'D:\\SDK\\SeaChangeKits\\RTFLib_SDK_2.0',
				     'RTFLIBSDKPATH'      => 'D:\\SDK\\SeaChangeKits\\CTFLib_1.0.0.18',
        	                     'OPENSSLPATH'      => 'D:\\SDK\\3rdPartyKits\\openssl',
        	                     'ICE_ROOT'		=> 'D:\\SDK\\3rdPartyKits\Ice-3.2.1-VC80-x64',
        	                     'STLPORT_ROOT'	=> 'D:\\SDK\\3rdPartyKits\\Ice-3.2.1-VC80-x64\\include\\stlport',
        	                     '3RDPARTYKITS_PATH' => 'D:\\SDK\\3rdPartyKits',
        	                     'ExpatPath'         => 'D:\\sdk\\3rdPartyKits\\expat_x64',
        	                     'RegExppKit'        => 'D:\\sdk\\3rdPartyKits\\regexpp1331',
        	                     'ANT_HOME'          => 'D:\\SDK\\3rdPartyKits\\apache-ant-1.6.5',
        	                     'SNMP_PLUS_ROOT'    => 'D:\\SDK\\3rdPartyKits\\SNMP',
        	                     'GSOAPPATH'	=>  'D:\\sdk\\3rdPartyKits\\gsoap-2.7.10\\gsoap',
        	                }, 
	'owner'		=> ['hui.shao@i-zq.com','ken.qian@i-zq.com','jie.zhang@i-zq.com'],
	'prod_ver'	=> '1.8.0',
	'sources'	=> ['ZQProjs/Common','ZQProjs/TianShan','ZQProjs/generic',],
	'work_path'	=> "ZQProjs\\TianShan",
	'rc_h_files'	=> [
			    "ZQProjs/Common/ZQCommVer.h",
	                    "ZQProjs/TianShan/ChannelOnDemand/PauseTVVersion.h",
	                    "ZQProjs/TianShan/StreamSmith/Service/ZQResource.h",
	                    "ZQProjs/TianShan/StreamSmith/Service/RtspProxyResource.h",
	                    "ZQProjs/TianShan/ContentStore/MediaCluster/ClusterContentStore/ZQResource.h",
	                    "ZQProjs/TianShan/ContentStore/MediaCluster/NodeContentStore/ZQResource.h",
	                    "ZQProjs/TianShan/ContentStore/MediaCluster/NASContentStore/ZQResource.h",
	                    "ZQProjs/TianShan/ContentStore/RDS/ZQResource.h",
	                    "ZQProjs/TianShan/ContentStore/RDA/ZQResource.h",
	                    "ZQProjs/TianShan/ContentStore/isaLink/isaLink/ZQResource.h",
	                    "ZQProjs/TianShan/StreamSmith/Modules/SsmTianShanS1_Now/ZQResource.h",
	                    "ZQProjs/TianShan/StreamSmith/Modules/ssm_tianshan/ZQResource.h",
	                    "ZQProjs/TianShan/StreamSmith/Modules/ssm_richurl/ZQResource.h",
	                    "ZQProjs/TianShan/Weiwoo/Service/ZQResource.h",
	                    "ZQProjs/TianShan/AccreditedPath/AdminControl/ZQResource.h",
	                    "ZQProjs/TianShan/AccreditedPath/ZQResource.h",
	                    "ZQProjs/TianShan/AccreditedPath/TestAdminCtl/ZQResource.h",
	                    "ZQProjs/TianShan/AccreditedPath/pho/pho_SeaChange/ZQResource.h",
	                    "ZQProjs/TianShan/application/MOD/ZQResource.h",
	                    "ZQProjs/TianShan/application/MOD2/ZQResource.h",
	                    "ZQProjs/TianShan/application/MODPlugIn/ZQResource.h",
	                    "ZQProjs/TianShan/Shell/ZQShell/ZQResource.h",
	                    "ZQProjs/TianShan/Sentry/Service/ZQResource.h",
	                    "ZQProjs/TianShan/SiteAdminSvc/Service/ZQResource.h",
	                    "ZQProjs/TianShan/ComcastNGOD/ssmNGODr2c1(Improved)/ZQResource.h",
	                    "ZQProjs/TianShan/ComcastNGOD/pho_NGOD_ss/ZQResource.h",
	                    "ZQProjs/TianShan/ComcastNGOD/ssm_ngod2/ZQResource.h",
	                    "ZQProjs/TianShan/ComcastNGOD/NSS/ZQResource.h",
	                    "ZQProjs/TianShan/ComcastNGOD/NSS/TSHammer/ZQResource.h",
	                    "ZQProjs/TianShan/ComcastNGOD/pho_NGOD/pho_NGOD/ZQResource.h",
	                    "ZQProjs/TianShan/Sentry/Plug_EventSender/snmp/ZQResource.h",
	                    "ZQProjs/TianShan/Sentry/Plug_EventSender/ZQResource.h",
	                    "ZQProjs/TianShan/Sentry/CodMan_web/ZQResource.h",
	                    "ZQProjs/TianShan/Sentry/AdminCtrl_web/ZQResource.h",
	                    "ZQProjs/TianShan/Sentry/CPCMan_web/ZQResource.h",
	                    "ZQProjs/TianShan/Sentry/CPEMan_web/ZQResource.h",
	                    "ZQProjs/TianShan/Sentry/Module/SysLogSender/ZQResource.h",
	                    "ZQProjs/TianShan/AccreditedPath/admin/ZQResource.h",
	                    "ZQProjs/TianShan/SiteAdminSvc/admin/ZQResource.h",
	                    "ZQProjs/TianShan/EventChannel/service/ZQResource.h",
	                    "ZQProjs/TianShan/CPE/ZQResource.h",
	                    "ZQProjs/TianShan/CPE/CPH_RDS/ZQResource.h",
	                    "ZQProjs/TianShan/CPE/CPH_RTFRDS/ZQResource.h",
	                    "ZQProjs/TianShan/CPE/CPH_NASCOPY/ZQResource.h",
	                    "ZQProjs/TianShan/CPE/CPH_RTI/ZQResource.h",
	                    "ZQProjs/TianShan/CPE/CPH_RTINAS/ZQResource.h",
	                    "ZQProjs/TianShan/EventGateway/service/ZQResource.h",
	                    "ZQProjs/TianShan/EventGateway/Modules/EGH_SOAP/EGH_SOAP_CME/ZQResource.h",
	                    "ZQProjs/TianShan/ComcastNGOD/ssm_ngod2/ngod2view/ZQResource.h",
	                    "ZQProjs/TianShan/VirtualStreamingSerivce/NGOD/ZQResource.h",
	                    "ZQProjs/TianShan/VirtualStreamingSerivce/pho/ZQResource.h",
	                    "ZQProjs/TianShan/VirtualStreamingSerivce/SsmHsnTree/ZQResource.h",
	                    "ZQProjs/TianShan/VirtualStreamingSerivce/HSN/ZQResource.h",
	                    "ZQProjs/TianShan/ICE/TianShanIce.ICE",
	                    ],
	'build_cmds'=> [
	                "$MSDEV8CMD /ReBuild  \"Release|x64\" /project Buildall_x64 /out opt_x64.log TianShanBuild.sln",
	                "TianShanPKG_64.bat"
	                ],
);

%ServerLoad = (
	'name'		=> 'ServerLoad',
	'desc'		=> 'ZQ ServerLoad',
        'environment'           => {
		                     'ITVSDKPATH'       => 'D:\\sdk\\SeaChangeKits\\ITVSDK-v3.2.INTERNAL',
        	                      'VSTRMKITPATH'        => 'D:\\SDK\\SeaChangeKits\\VstrmKitV5.3.10',      #For RDA
        	                      'VSTRMPATH'        => 'D:\\SDK\\SeaChangeKits\\VstrmKitV5.3.10\\SDK',         #For RDA

        	                     'OPENSSLPATH'      => 'D:\\SDK\\3rdPartyKits\\openssl',
        	                     'ICE_ROOT'		=> 'D:\\SDK\\3rdPartyKits\\Ice-3.1.0-VC60',
        	                     'STLPORT_ROOT'	=> 'D:\\SDK\\3rdPartyKits\\Ice-3.1.0-VC60\\include\\stlport',
        	                     '3RDPARTYKITS_PATH' => 'D:\\SDK\\3rdPartyKits',
        	                     'ExpatPath'         => 'D:\\SDK\\3rdPartyKits\\expat',
        	                     'ANT_HOME'          => 'D:\\SDK\\3rdPartyKits\\apache-ant-1.6.5',
        	                }, 
	'owner'		=> ['Guan.han@i-zq.com'],
	'prod_ver'	=> '1.1.0',
	'sources'	=> ['ZQProjs/Common','ZQProjs/TianShan','ZQProjs/generic/ServerLoad',],
	'work_path'	=> "ZQProjs\\Generic\\ServerLoad",
	'rc_h_files'	=> [
	                    "ZQProjs/Generic/ServerLoad/ZQResource.h",
	                    ],
	'build_cmds'=> [
	                "$MSDEV6CMD .\\ServerLoad.dsw /MAKE \"ServerLoad - Win32 Release\" /BUILD",
	                "package.bat",
	                ],
	'output_pkg'	=> ["ZQProjs\\Generic\\ServerLoad\\ServerLoad_setup.zip" ]
);


%CLink = (
	'name'		=> 'CLink',
	'desc'		=> 'ZQ ContentDistribution Service',
	'xml_path'	=> ['ZQProjs\\ContentDistribution\\source\\etc'],
	'owner'		=> 'li.huang@i-zq.com,xia.chen@i-zq.com,haoyuan.lu@i-zq.com',
	'environment'           => {
		                     'ACE_ROOT'		=> 'D:\\SDK\\3rdPartyKits\\ACE_5.3a_p15',
		                     'WMThomsonSDKPath'	=> 'D:\\SDK\\3rdPartyKits\\WatermarkingSDK\\Thomson',
		                     'ICE_ROOT'		=> 'D:\\SDK\\3rdPartyKits\\Ice-3.2.1-VC80-x86',
        	                     'STLPORT_ROOT'	=> 'D:\\SDK\\3rdPartyKits\\Ice-3.2.1-VC80-x86\\include\\stlport',
        	                     'ExpatPath'	=> 'D:\\SDK\\3rdPartyKits\\expat',
        	                     'RegExppKit'	=> 'D:\\sdk\\3rdPartyKits\\regexpp1331',
		                     
		                },
	'prod_ver'	=> '1.0.2',
	'sources'	=> ['ZQProjs/Common','ZQProjs/TianShan/common','ZQProjs/TianShan/Shell','ZQProjs/TianShan/Include','ZQProjs/TianShan/Ice','ZQProjs/TianShan/EventChannel','ZQProjs/TianShan/EventGateway','ZQProjs/ContentDistribution','ZQProjs/generic/JMSCppLib'],
	'work_path'	=> "ZQProjs\\ContentDistribution",
	'rc_h_files'	=> ['ZQProjs/ContentDistribution/Source/TransEngine/ZQResource.h',
			    'ZQProjs/ContentDistribution/Source/TransMissionMgr/ZQResource.h',
			    'ZQProjs/ContentDistribution/Source/TaskScheduler/ZQResource.h',
			    'ZQProjs/ContentDistribution/Source/TransMSchedule/ZQResource.h',	
			    'ZQProjs/ContentDistribution/Source/ReceiverManager/ZQResource.h',	
			    'ZQProjs/ContentDistribution/Source/ProvisionAgent/ZQResource.h',	
			    'ZQProjs/ContentDistribution/Source/ContentPitcher/ZQResource.h',
			    'ZQProjs/ContentDistribution/Source/ProvisionAMS/ZQResource.h',
			    'ZQProjs/ContentDistribution/Source/WaterMarking/ZQResource.h',
			    'ZQProjs/ContentDistribution/Source/EncryptDll/ZQResource.h',
			    'ZQProjs/ContentDistribution/Source/EGH_CLE/ZQResource.h',
			    'ZQProjs/TianShan/Shell/ZQShell/ZQResource.h',
			    "ZQProjs/TianShan/EventGateway/service/ZQResource.h",
			    "ZQProjs/TianShan/EventChannel/service/ZQResource.h",
			    'ZQProjs/Common/ZQCommVer.h',
			   ],
	'build_cmds'=> [
	"$MSDEV8CMD /Rebuild  \"Release|win32\" /project BuildAll /out Buildall.log .\\source\\BuildAll.sln",
	"CDSPKG.bat"],
	'output_pkg'	=> ["ZQProjs\\ContentDistribution\\CDS_Setup.zip" ],
);

@NIGHLY_PROJLIST = (
#	ProjTemplate,
	TianShanDataOnDemand,
	TianShan,
	ServerLoad,
	ContentLink,
	TianShan_x64,
	CLink,
);

@ALL_PROJS =(
	ProjTemplate,
	TianShan,
	TianShanDataOnDemand,
	ServerLoad,
	ContentLink,
	TianShan_x64,
	CLink,
);

